import{S as N,k as S,v as _,x as R}from"./jsx-runtime.js";var F=S({buildChatFullPrompt:()=>k,buildChatSystemPrompt:()=>B,extractCommandsAndCleanText:()=>$,isUserWebTab:()=>M,parseCommandArgs:()=>v,sanitizeStreamChunk:()=>x});function M(d){const f=d.url||d.pendingUrl||"";if(!f||typeof f!="string")return!1;const t=f.toLowerCase().trim();return!(!t.startsWith("http://")&&!t.startsWith("https://")||t.startsWith("chrome://")||t.startsWith("chrome-extension://")||t.startsWith("moz-extension://")||t.startsWith("edge://")||t.startsWith("about:")||t.startsWith("devtools://")||t.includes("localhost:5173")||t.includes("127.0.0.1:5173")||t.includes("localhost:3000")||t.includes("127.0.0.1:3000")||t.includes("localhost:4173")||t.includes("127.0.0.1:4173")||t.includes("/src/dashboard/")||t.includes("/src/popup/"))}function B(){return`You are the Tabflow AI Browser Assistant. 
You help users manage workspaces, browse context, summarize tabs, search the web, and trigger browser actions.

CRITICAL INSTRUCTIONS & FORMAT PROTOCOL:
1. In the context below, you will see two clear sections:
   - "ACTIVE OPEN BROWSER TABS": The user's currently active open tabs in their browser.
   - "SAVED WORKSPACE FOLDERS": The user's saved folders and tabs in Tabflow.
2. When the user asks to "Summarize my active tabs" or asks about their tabs:
   - IF ACTIVE OPEN BROWSER TABS ARE LISTED:
     Give a concise, well-structured summary of those currently open tabs. Explain the purpose of each tab and how they relate.
   - IF NO ACTIVE OPEN BROWSER TABS ARE OPEN:
     State clearly: "You currently have no external browser tabs open."
     Then provide a helpful overview of the tabs saved inside their workspace folders (e.g. what's stored in each folder).
   - NEVER invent or list fake tabs (such as React, Vite, or Tailwind) unless they are explicitly present in the context.
   - NEVER list Tabflow itself, extension URLs, or localhost dashboard pages as open user tabs.
3. You do NOT have external browser navigation or function-calling tools.
4. NEVER output XML tags or function-calling blocks such as <dots_function_call>, <invoke>, <function_calls>, or <tool_call>.
5. When asked to "Find the latest news on AI" or search for a topic, provide a helpful, concise summary of recent developments, and append a command to open search results.
6. When asked to "Play some focus music on YouTube" or open music/videos, provide a brief encouraging reply, and append a command to open YouTube.
7. Available Commands (Append each on its own line at the very end of your response using key="value" format):
   - COMMAND: OPEN_TAB url="<url>"
   - COMMAND: CLOSE_TAB url="<url_or_domain>" title="<title_keyword>" all="<true_or_false>"
   - COMMAND: DELETE_TAB folder="<folder_name_or_id>" url="<url>"
   - COMMAND: DELETE_FOLDER folder="<folder_name_or_id>"
   - COMMAND: MOVE_TAB src="<src_folder>" dest="<dest_folder>" url="<url>"
   - COMMAND: COPY_TAB src="<src_folder>" dest="<dest_folder>" url="<url>"
   - COMMAND: ADD_TAB folder="<folder_name_or_id>" url="<url>" title="<title>"
   - COMMAND: RENAME_FOLDER folder="<old_name_or_id>" new_name="<new_name>"
   - COMMAND: RESTORE_FOLDER folder="<folder_name_or_id>"
   - COMMAND: SCHEDULE_FOLDER folder="<folder_name_or_id>" action="<open_or_close>" time="<epoch_milliseconds>"
   - COMMAND: SCHEDULE_TAB folder="<folder_name_or_id>" url="<url>" action="<open_or_close>" time="<epoch_milliseconds>"
   - COMMAND: CLEAR_SCHEDULE folder="<folder_name_or_id>" url="<optional_tab_url>"
   - COMMAND: LOCK_FOLDER folder="<folder_name_or_id>"

8. CRITICAL RULE FOR TAB ORGANIZATION & SAVING TABS INTO FOLDERS:
   - You CANNOT organize tabs or create folders by merely writing conversational text.
   - When the user asks to organize, group, or save tabs into folders, OR whenever the user confirms / replies "yes", "proceed", "sure", or "go ahead" after a proposed folder categorization:
     a) Announce the folders you are organizing the tabs into.
     b) YOU MUST EMIT A COMMAND LINE FOR EACH TAB:
        COMMAND: ADD_TAB folder="<FolderName>" url="<TabURL>" title="<TabTitle>"
     c) NEVER say "Your tabs have been successfully organized into folders" or "Adding tab to folder" without appending the corresponding COMMAND: ADD_TAB commands at the very end!
     d) If you do not append the COMMAND: ADD_TAB lines, NO FOLDERS OR TABS WILL BE CREATED IN TABFLOW!

Output ONLY user-facing markdown text followed optionally by one or more COMMAND: lines.`}function k(d,f,t,m=[]){const i=`Current local time: ${new Date().toString()} (Epoch milliseconds: ${Date.now()})

`,C=f.filter(M);let g=`### ACTIVE OPEN BROWSER TABS:
`;if(C.length===0)g+=`(No external browser tabs currently open. The user only has Tabflow open.)

`;else{for(const n of C){const a=_(N(n.title||n.url||"Untitled"));g+=`- Title: "${a}"
  URL: ${n.url}
`}g+=`
`}let p=`### SAVED WORKSPACE FOLDERS:
`;if(!t||t.length===0)p+=`(No saved workspace folders.)

`;else{for(const n of t){if(n.isLocked){p+=`- Folder: "${N(n.name)}" (ID: ${n.id}) [LOCKED — contents hidden]
`;continue}if(p+=`- Folder: "${N(n.name)}" (ID: ${n.id}) [${n.tabs?.length||0} tabs]:
`,!n.tabs||n.tabs.length===0)p+=`    (No tabs in this folder)
`;else for(const a of n.tabs){const o=_(N(a.title||a.url||"Untitled"));p+=`    * "${o}" — ${a.url}
`}}p+=`
`}let w="";if(m&&Array.isArray(m)){w=`### CONVERSATION HISTORY:
`;const n=m.slice(-8);for(const a of n){const o=a.role==="user"?"User":"Assistant";w+=`${o}: ${a.content}
`}w+=`
`}return`${i}${g}${p}${w}User Question: ${d}`}function v(d){const f={},t=/(\w+)="([^"]*)"/g;let m;for(;(m=t.exec(d))!==null;)f[m[1]]=m[2];return f}function $(d,f=[],t=[],m=""){const i=[],C=[],g=/(?:\*\*|)?(?:COMMAND:|<tool_call>)\s*(OPEN_TAB|DELETE_TAB|DELETE_FOLDER|MOVE_TAB|COPY_TAB|ADD_TAB|CLOSE_TAB|RENAME_FOLDER|RESTORE_FOLDER|SCHEDULE_FOLDER|SCHEDULE_TAB|CLEAR_SCHEDULE|LOCK_FOLDER)\s+([^<\n*]+?)(?:>|\*\*|)?(?=\n|$)/gi;let p;for(;(p=g.exec(d))!==null;){C.push(p[0]);const o=p[1].toUpperCase(),u=v(p[2].trim());i.push({type:o,args:u,raw:p[0]})}const w=/<invoke\s+name="([^"]+)"[\s\S]*?>([\s\S]*?)<\/invoke>/gi;let n;for(;(n=w.exec(d))!==null;){const o=n[1].toLowerCase(),u=n[2],T=/<parameter\s+name="([^"]+)"\s*>(.*?)<\/parameter>/gi;let l;const r={};for(;(l=T.exec(u))!==null;)r[l[1].toLowerCase()]=l[2].trim();if(o==="browser_navigate"||o==="open_tab"||o==="browser_open")if(r.url&&R(r.url))i.push({type:"OPEN_TAB",args:{url:r.url},raw:n[0]});else if(r.search_query||r.query){const e=r.search_query||r.query;i.push({type:"OPEN_TAB",args:{url:`https://www.google.com/search?q=${encodeURIComponent(e)}`},raw:n[0]})}else(r.action==="youtube"||r.action==="music")&&i.push({type:"OPEN_TAB",args:{url:"https://www.youtube.com/results?search_query=focus+music"},raw:n[0]})}if(!i.some(o=>o.type==="ADD_TAB")){const o=d.split(`
`);let u=null;const T=[...f];t&&Array.isArray(t)&&t.forEach(r=>{r.tabs&&T.push(...r.tabs)});const l=r=>{const e=_(r).toLowerCase();return T.find(A=>{if(!A)return!1;const E=_(A.title||"").toLowerCase(),s=(A.url||"").toLowerCase();return!!(E&&(E===e||E.includes(e)||e.includes(E))||e.includes("chatgpt")&&s.includes("chatgpt")||e.includes("gemini")&&s.includes("gemini")||e.includes("openrouter")&&s.includes("openrouter")||e.includes("youtube")&&s.includes("youtube")||(e.includes("twitter")||e.includes("x ("))&&(s.includes("twitter")||s.includes("x.com"))||e.includes("linkedin")&&s.includes("linkedin")||e.includes("keep")&&s.includes("keep.google")||e.includes("apollo")&&s.includes("apollo.io")||e.includes("maps")&&(s.includes("maps")||s.includes("apify"))||e.includes("color hunt")&&s.includes("colorhunt")||e.includes("github")&&s.includes("github")||e.includes("vercel")&&s.includes("vercel"))})};for(const r of o){const e=r.trim();if(!e)continue;const A=e.match(/^(?:###\s*|\*\*\s*|\d+[\.\)]\s*)?([A-Za-z0-9\s&/\-_]+?)(?:\s+Folder|\s+Workspace)?(?:\*\*)?:\s*$/i);if(A&&!e.toLowerCase().includes("proposed folder")&&!e.toLowerCase().includes("creating and organizing")&&!e.toLowerCase().includes("organize your")){const s=A[1].trim();if(s.length>=2&&s.length<=40){u=s;continue}}const E=e.match(/^Adding\s+(.+?)\s+to\s+(?:the\s+)?(.+?)(?:\s+folder|\s+workspace)?$/i);if(E){const s=E[1].trim(),O=(E[2]?.trim()||u||"General").replace(/^["']|["']$/g,""),c=l(s);c&&c.url&&(i.some(h=>h.type==="ADD_TAB"&&h.args.url===c.url)||i.push({type:"ADD_TAB",args:{folder:O,url:c.url,title:_(c.title||s)},raw:`COMMAND: ADD_TAB folder="${O}" url="${c.url}" title="${_(c.title||s)}"`}));continue}if(u){const s=e.match(/^(?:[-*•]\s*)?(?:\[(.+?)\]\((https?:\/\/[^\s)]+)\)|([^(]+?)\s*\((https?:\/\/[^\s)]+)\))/i);if(s){const c=_((s[1]||s[3]||"").trim()),h=(s[2]||s[4]||"").trim();R(h)&&(i.some(y=>y.type==="ADD_TAB"&&y.args.url===h)||i.push({type:"ADD_TAB",args:{folder:u,url:h,title:c||h},raw:`COMMAND: ADD_TAB folder="${u}" url="${h}" title="${c||h}"`}));continue}const O=e.match(/^([A-Za-z0-9\s&/\-_]+?)\s*[-–—:]\s*(.+)$/i);if(O&&!e.startsWith("Adding")&&!e.toLowerCase().startsWith("http")){const c=O[1].trim(),h=O[2].trim();if(c.length>=2&&c.length<=40&&h.includes(",")){const y=h.split(",").map(D=>D.trim());for(const D of y){const b=l(D);b&&b.url&&(i.some(L=>L.type==="ADD_TAB"&&L.args.url===b.url)||i.push({type:"ADD_TAB",args:{folder:c,url:b.url,title:_(b.title||D)},raw:`COMMAND: ADD_TAB folder="${c}" url="${b.url}" title="${_(b.title||D)}"`}))}}}}}}let a=d;for(const o of C)a=a.replace(o,"");if(a=a.replace(/<dots_function_call>[\s\S]*?<\/dots_function_call>/gi,"").replace(/<invoke[\s\S]*?<\/invoke>/gi,"").replace(/<function_calls>[\s\S]*?<\/function_calls>/gi,"").replace(/<tool_call>[\s\S]*?<\/tool_call>/gi,"").replace(/<\/?(?:dots_function_call|invoke|parameter|tool_call|function_calls)[^>]*>/gi,"").trim(),!a){const o=m.toLowerCase(),u=f.filter(M),T=t&&t.length>0;if(o.includes("summar")||o.includes("tab")||o.includes("active")||o.includes("workspace")){let l="";u.length>0?l+=`### 📑 Active Open Browser Tabs

Here are the ${u.length} tab${u.length>1?"s":""} currently active in your browser:

`+u.map((r,e)=>`${e+1}. **${r.title||"Untitled"}**
   *${r.url}*`).join(`

`):l+=`### 📑 Active Open Browser Tabs

*You currently have no external browser tabs open.*`,T&&(l+=`

---

### 📂 Saved Workspaces Context

`,t.forEach(r=>{if(r.isLocked){l+=`#### **${r.name}** [🔒 Locked]
*(Unlock this folder in Folders view to inspect tabs)*

`;return}const e=r.tabs?.length||0;l+=`#### **${r.name}** (${e} tab${e===1?"":"s"})
`,r.tabs&&r.tabs.length>0?l+=r.tabs.map(A=>`- **${A.title||"Untitled"}** (*${A.url}*)`).join(`
`)+`

`:l+=`*(Empty folder)*

`})),l+=`
*You can ask me to open tabs, group them into a workspace, close inactive tabs, or set open/close timers.*`,a=l}else o.includes("news")||o.includes("ai")?(a=`### 🔍 AI News & Updates

I have prepared a live search for the latest news and breakthroughs in AI. Click **Approve & Execute** below to open the search results in a new tab.`,i.some(l=>l.type==="OPEN_TAB")||i.push({type:"OPEN_TAB",args:{url:"https://www.google.com/search?q=latest+news+on+AI"},raw:'COMMAND: OPEN_TAB url="https://www.google.com/search?q=latest+news+on+AI"'})):o.includes("music")||o.includes("youtube")||o.includes("focus")?(a=`### 🎵 Focus Music on YouTube

I have prepared a curated focus and study music stream for you on YouTube. Click **Approve & Execute** below to launch it.`,i.some(l=>l.type==="OPEN_TAB")||i.push({type:"OPEN_TAB",args:{url:"https://www.youtube.com/results?search_query=focus+music+work+study"},raw:'COMMAND: OPEN_TAB url="https://www.youtube.com/results?search_query=focus+music+work+study"'})):a="I have processed your request. Please review the suggested workspace actions below."}return{cleanedText:a,pendingCommands:i}}function x(d){return d.replace(/<dots_function_call>[\s\S]*?<\/dots_function_call>/gi,"").replace(/<invoke[\s\S]*?<\/invoke>/gi,"").replace(/<\/?(?:dots_function_call|invoke|parameter|tool_call|function_calls)[^>]*>/gi,"").replace(/(?:\*\*|)?COMMAND:[^\n]*\n?/gi,"")}export{x as n,F as t};
