import{E as O,b as f,y as C}from"./jsx-runtime.js";var v=O({buildChatFullPrompt:()=>g,buildChatSystemPrompt:()=>T,extractCommandsAndCleanText:()=>y,isUserWebTab:()=>w,parseCommandArgs:()=>A,sanitizeStreamChunk:()=>D});function w(l){const c=l.url||l.pendingUrl||"";if(!c||typeof c!="string")return!1;const e=c.toLowerCase().trim();return!(!e.startsWith("http://")&&!e.startsWith("https://")||e.startsWith("chrome://")||e.startsWith("chrome-extension://")||e.startsWith("moz-extension://")||e.startsWith("edge://")||e.startsWith("about:")||e.startsWith("devtools://")||e.includes("localhost:5173")||e.includes("127.0.0.1:5173")||e.includes("localhost:3000")||e.includes("127.0.0.1:3000")||e.includes("localhost:4173")||e.includes("127.0.0.1:4173")||e.includes("/src/dashboard/")||e.includes("/src/popup/"))}function T(){return`You are the Tabflow AI Browser Assistant. 
You help users manage workspaces, browse context, summarize tabs, search the web, and trigger browser actions.

CRITICAL INSTRUCTIONS & FORMAT PROTOCOL:
1. In the context below, you will see two clear sections:
   - "ACTIVE OPEN BROWSER TABS": The user's currently active open tabs in their browser.
   - "SAVED WORKSPACE FOLDERS": The user's saved folders and tabs in Tabflow.
2. When the user asks to "Summarize my active tabs" or asks about their tabs:
   - IF ACTIVE OPEN BROWSER TABS ARE LISTED:
     Give a concise, well-structured summary of those currently open tabs. Explain the purpose of each tab and how they relate.
   - IF NO ACTIVE OPEN BROWSER TABS ARE OPEN:
     State clearly: "You currently have no external browser tabs open."
     Then provide a helpful overview of the tabs saved inside their workspace folders (e.g. what's stored in each folder).
   - NEVER invent or list fake tabs (such as React, Vite, or Tailwind) unless they are explicitly present in the context.
   - NEVER list Tabflow itself, extension URLs, or localhost dashboard pages as open user tabs.
3. You do NOT have external browser navigation or function-calling tools.
4. NEVER output XML tags or function-calling blocks such as <dots_function_call>, <invoke>, <function_calls>, or <tool_call>.
5. When asked to "Find the latest news on AI" or search for a topic, provide a helpful, concise summary of recent developments, and append a command to open search results.
6. When asked to "Play some focus music on YouTube" or open music/videos, provide a brief encouraging reply, and append a command to open YouTube.
7. Available Commands (Append each on its own line at the very end of your response using key="value" format):
   - COMMAND: OPEN_TAB url="<url>"
   - COMMAND: CLOSE_TAB url="<url_or_domain>" title="<title_keyword>" all="<true_or_false>"
   - COMMAND: DELETE_TAB folder="<folder_name_or_id>" url="<url>"
   - COMMAND: DELETE_FOLDER folder="<folder_name_or_id>"
   - COMMAND: MOVE_TAB src="<src_folder>" dest="<dest_folder>" url="<url>"
   - COMMAND: COPY_TAB src="<src_folder>" dest="<dest_folder>" url="<url>"
   - COMMAND: ADD_TAB folder="<folder_name_or_id>" url="<url>" title="<title>"
   - COMMAND: RENAME_FOLDER folder="<old_name_or_id>" new_name="<new_name>"
   - COMMAND: RESTORE_FOLDER folder="<folder_name_or_id>"
   - COMMAND: SCHEDULE_FOLDER folder="<folder_name_or_id>" action="<open_or_close>" time="<epoch_milliseconds>"
   - COMMAND: SCHEDULE_TAB folder="<folder_name_or_id>" url="<url>" action="<open_or_close>" time="<epoch_milliseconds>"
   - COMMAND: CLEAR_SCHEDULE folder="<folder_name_or_id>" url="<optional_tab_url>"
   - COMMAND: LOCK_FOLDER folder="<folder_name_or_id>"

Output ONLY user-facing markdown text followed optionally by one or more COMMAND: lines.`}function g(l,c,e,u=[]){const i=`Current local time: ${new Date().toString()} (Epoch milliseconds: ${Date.now()})

`,m=c.filter(w);let p=`### ACTIVE OPEN BROWSER TABS:
`;if(m.length===0)p+=`(No external browser tabs currently open. The user only has Tabflow open.)

`;else{for(const t of m)p+=`- Title: "${f(t.title||t.url||"Untitled")}"
  URL: ${t.url}
`;p+=`
`}let a=`### SAVED WORKSPACE FOLDERS:
`;if(!e||e.length===0)a+=`(No saved workspace folders.)

`;else{for(const t of e){if(t.isLocked){a+=`- Folder: "${f(t.name)}" (ID: ${t.id}) [LOCKED — contents hidden]
`;continue}if(a+=`- Folder: "${f(t.name)}" (ID: ${t.id}) [${t.tabs?.length||0} tabs]:
`,!t.tabs||t.tabs.length===0)a+=`    (No tabs in this folder)
`;else for(const n of t.tabs)a+=`    * "${f(n.title||n.url||"Untitled")}" — ${n.url}
`}a+=`
`}let h="";if(u&&Array.isArray(u)){h=`### CONVERSATION HISTORY:
`;const t=u.slice(-8);for(const n of t){const s=n.role==="user"?"User":"Assistant";h+=`${s}: ${n.content}
`}h+=`
`}return`${i}${p}${a}${h}User Question: ${l}`}function A(l){const c={},e=/(\w+)="([^"]*)"/g;let u;for(;(u=e.exec(l))!==null;)c[u[1]]=u[2];return c}function y(l,c=[],e=[],u=""){const i=[],m=[],p=/(?:\*\*|)?(?:COMMAND:|<tool_call>)\s*(OPEN_TAB|DELETE_TAB|DELETE_FOLDER|MOVE_TAB|COPY_TAB|ADD_TAB|CLOSE_TAB|RENAME_FOLDER|RESTORE_FOLDER|SCHEDULE_FOLDER|SCHEDULE_TAB|CLEAR_SCHEDULE|LOCK_FOLDER)\s+([^<\n*]+?)(?:>|\*\*|)?(?=\n|$)/gi;let a;for(;(a=p.exec(l))!==null;){m.push(a[0]);const s=a[1].toUpperCase(),d=A(a[2].trim());i.push({type:s,args:d,raw:a[0]})}const h=/<invoke\s+name="([^"]+)"[\s\S]*?>([\s\S]*?)<\/invoke>/gi;let t;for(;(t=h.exec(l))!==null;){const s=t[1].toLowerCase(),d=t[2],E=/<parameter\s+name="([^"]+)"\s*>(.*?)<\/parameter>/gi;let r;const o={};for(;(r=E.exec(d))!==null;)o[r[1].toLowerCase()]=r[2].trim();if(s==="browser_navigate"||s==="open_tab"||s==="browser_open")if(o.url&&C(o.url))i.push({type:"OPEN_TAB",args:{url:o.url},raw:t[0]});else if(o.search_query||o.query){const _=o.search_query||o.query;i.push({type:"OPEN_TAB",args:{url:`https://www.google.com/search?q=${encodeURIComponent(_)}`},raw:t[0]})}else(o.action==="youtube"||o.action==="music")&&i.push({type:"OPEN_TAB",args:{url:"https://www.youtube.com/results?search_query=focus+music"},raw:t[0]})}let n=l;for(const s of m)n=n.replace(s,"");if(n=n.replace(/<dots_function_call>[\s\S]*?<\/dots_function_call>/gi,"").replace(/<invoke[\s\S]*?<\/invoke>/gi,"").replace(/<function_calls>[\s\S]*?<\/function_calls>/gi,"").replace(/<tool_call>[\s\S]*?<\/tool_call>/gi,"").replace(/<\/?(?:dots_function_call|invoke|parameter|tool_call|function_calls)[^>]*>/gi,"").trim(),!n){const s=u.toLowerCase(),d=c.filter(w),E=e&&e.length>0;if(s.includes("summar")||s.includes("tab")||s.includes("active")||s.includes("workspace")){let r="";d.length>0?r+=`### 📑 Active Open Browser Tabs

Here are the ${d.length} tab${d.length>1?"s":""} currently active in your browser:

`+d.map((o,_)=>`${_+1}. **${o.title||"Untitled"}**
   *${o.url}*`).join(`

`):r+=`### 📑 Active Open Browser Tabs

*You currently have no external browser tabs open.*`,E&&(r+=`

---

### 📂 Saved Workspaces Context

`,e.forEach(o=>{if(o.isLocked){r+=`#### **${o.name}** [🔒 Locked]
*(Unlock this folder in Folders view to inspect tabs)*

`;return}const _=o.tabs?.length||0;r+=`#### **${o.name}** (${_} tab${_===1?"":"s"})
`,o.tabs&&o.tabs.length>0?r+=o.tabs.map(b=>`- **${b.title||"Untitled"}** (*${b.url}*)`).join(`
`)+`

`:r+=`*(Empty folder)*

`})),r+=`
*You can ask me to open tabs, group them into a workspace, close inactive tabs, or set open/close timers.*`,n=r}else s.includes("news")||s.includes("ai")?(n=`### 🔍 AI News & Updates

I have prepared a live search for the latest news and breakthroughs in AI. Click **Approve & Execute** below to open the search results in a new tab.`,i.some(r=>r.type==="OPEN_TAB")||i.push({type:"OPEN_TAB",args:{url:"https://www.google.com/search?q=latest+news+on+AI"},raw:'COMMAND: OPEN_TAB url="https://www.google.com/search?q=latest+news+on+AI"'})):s.includes("music")||s.includes("youtube")||s.includes("focus")?(n=`### 🎵 Focus Music on YouTube

I have prepared a curated focus and study music stream for you on YouTube. Click **Approve & Execute** below to launch it.`,i.some(r=>r.type==="OPEN_TAB")||i.push({type:"OPEN_TAB",args:{url:"https://www.youtube.com/results?search_query=focus+music+work+study"},raw:'COMMAND: OPEN_TAB url="https://www.youtube.com/results?search_query=focus+music+work+study"'})):n="I have processed your request. Please review the suggested workspace actions below."}return{cleanedText:n,pendingCommands:i}}function D(l){return l.replace(/<dots_function_call>[\s\S]*?<\/dots_function_call>/gi,"").replace(/<invoke[\s\S]*?<\/invoke>/gi,"").replace(/<\/?(?:dots_function_call|invoke|parameter|tool_call|function_calls)[^>]*>/gi,"").replace(/(?:\*\*|)?COMMAND:[^\n]*\n?/gi,"")}export{D as n,v as t};
