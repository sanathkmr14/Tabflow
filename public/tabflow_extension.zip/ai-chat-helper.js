import{S as N,k as S,v as A,x as R}from"./jsx-runtime.js";var F=S({buildChatFullPrompt:()=>k,buildChatSystemPrompt:()=>B,extractCommandsAndCleanText:()=>$,isUserWebTab:()=>M,parseCommandArgs:()=>v,sanitizeStreamChunk:()=>I});function M(d){const h=d.url||d.pendingUrl||"";if(!h||typeof h!="string")return!1;const t=h.toLowerCase().trim();return!(!t.startsWith("http://")&&!t.startsWith("https://")||t.startsWith("chrome://")||t.startsWith("chrome-extension://")||t.startsWith("moz-extension://")||t.startsWith("edge://")||t.startsWith("about:")||t.startsWith("devtools://")||t.includes("localhost:5173")||t.includes("127.0.0.1:5173")||t.includes("localhost:3000")||t.includes("127.0.0.1:3000")||t.includes("localhost:4173")||t.includes("127.0.0.1:4173")||t.includes("/src/dashboard/")||t.includes("/src/popup/"))}function B(){return`You are the Tabflow AI Browser Assistant. 
You help users manage workspaces, browse context, summarize tabs, search the web, and trigger browser actions.

CRITICAL INSTRUCTIONS & FORMAT PROTOCOL:
1. In the context below, you will see two clear sections:
   - "ACTIVE OPEN BROWSER TABS": The user's currently active open tabs in their browser.
   - "SAVED WORKSPACE FOLDERS": The user's saved folders and tabs in Tabflow.
2. When the user asks to "Summarize my active tabs" or asks about their tabs:
   - IF ACTIVE OPEN BROWSER TABS ARE LISTED:
     Give a concise, well-structured summary of those currently open tabs. Explain the purpose of each tab and how they relate.
   - IF NO ACTIVE OPEN BROWSER TABS ARE OPEN:
     State clearly: "You currently have no external browser tabs open."
     Then provide a helpful overview of the tabs saved inside their workspace folders (e.g. what's stored in each folder).
   - NEVER invent or list fake tabs (such as React, Vite, or Tailwind) unless they are explicitly present in the context.
   - NEVER list Tabflow itself, extension URLs, or localhost dashboard pages as open user tabs.
3. You do NOT have external browser navigation or function-calling tools.
4. NEVER output XML tags or function-calling blocks such as <dots_function_call>, <invoke>, <function_calls>, or <tool_call>.
5. When asked to "Find the latest news on AI" or search for a topic, provide a helpful, concise summary of recent developments, and append a command to open search results.
6. When asked to "Play some focus music on YouTube" or open music/videos, provide a brief encouraging reply, and append a command to open YouTube.
7. Available Commands (Append each on its own line at the very end of your response using key="value" format):
   - COMMAND: OPEN_TAB url="<url>"
   - COMMAND: CLOSE_TAB url="<url_or_domain>" title="<title_keyword>" all="<true_or_false>"
   - COMMAND: DELETE_TAB folder="<folder_name_or_id>" url="<url>"
   - COMMAND: DELETE_FOLDER folder="<folder_name_or_id>"
   - COMMAND: MOVE_TAB src="<src_folder>" dest="<dest_folder>" url="<url>"
   - COMMAND: COPY_TAB src="<src_folder>" dest="<dest_folder>" url="<url>"
   - COMMAND: ADD_TAB folder="<folder_name_or_id>" url="<url>" title="<title>"
   - COMMAND: RENAME_FOLDER folder="<old_name_or_id>" new_name="<new_name>"
   - COMMAND: RESTORE_FOLDER folder="<folder_name_or_id>"
   - COMMAND: SCHEDULE_FOLDER folder="<folder_name_or_id>" action="<open_or_close>" time="<epoch_milliseconds>"
   - COMMAND: SCHEDULE_TAB folder="<folder_name_or_id>" url="<url>" action="<open_or_close>" time="<epoch_milliseconds>"
   - COMMAND: CLEAR_SCHEDULE folder="<folder_name_or_id>" url="<optional_tab_url>"
   - COMMAND: LOCK_FOLDER folder="<folder_name_or_id>"
   - COMMAND: EDIT_TAB folder="<folder_name_or_id>" url="<current_url>" new_title="<new_title>" new_url="<optional_new_url>"

8. CRITICAL RULE FOR TAB ORGANIZATION & SAVING TABS INTO FOLDERS:
   - You CANNOT organize tabs or create folders by merely writing conversational text.
   - When the user asks to organize, group, or save tabs into folders, OR whenever the user confirms / replies "yes", "proceed", "sure", or "go ahead" after a proposed folder categorization:
     a) Announce the folders you are organizing the tabs into.
     b) YOU MUST EMIT A COMMAND LINE FOR EACH TAB:
        COMMAND: ADD_TAB folder="<FolderName>" url="<TabURL>" title="<TabTitle>"
     c) NEVER say "Your tabs have been successfully organized into folders" or "Adding tab to folder" without appending the corresponding COMMAND: ADD_TAB commands at the very end!
     d) If you do not append the COMMAND: ADD_TAB lines, NO FOLDERS OR TABS WILL BE CREATED IN TABFLOW!

Output ONLY user-facing markdown text followed optionally by one or more COMMAND: lines.`}function k(d,h,t,m=[]){const i=`Current local time: ${new Date().toString()} (Epoch milliseconds: ${Date.now()})

`,C=h.filter(M);let w=`### ACTIVE OPEN BROWSER TABS:
`;if(C.length===0)w+=`(No external browser tabs currently open. The user only has Tabflow open.)

`;else{for(const s of C){const a=A(N(s.title||s.url||"Untitled"));w+=`- Title: "${a}"
  URL: ${s.url}
`}w+=`
`}let p=`### SAVED WORKSPACE FOLDERS:
`;if(!t||t.length===0)p+=`(No saved workspace folders.)

`;else{for(const s of t){if(s.isLocked){p+=`- Folder: "${N(s.name)}" (ID: ${s.id}) [LOCKED — contents hidden]
`;continue}if(p+=`- Folder: "${N(s.name)}" (ID: ${s.id}) [${s.tabs?.length||0} tabs]:
`,!s.tabs||s.tabs.length===0)p+=`    (No tabs in this folder)
`;else for(const a of s.tabs){const n=A(N(a.title||a.url||"Untitled"));p+=`    * "${n}" — ${a.url}
`}}p+=`
`}let b="";if(m&&Array.isArray(m)){b=`### CONVERSATION HISTORY:
`;const s=m.slice(-8);for(const a of s){const n=a.role==="user"?"User":"Assistant";b+=`${n}: ${a.content}
`}b+=`
`}return`${i}${w}${p}${b}User Question: ${d}`}function v(d){const h={},t=/(\w+)="([^"]*)"/g;let m;for(;(m=t.exec(d))!==null;)h[m[1]]=m[2];return h}function $(d,h=[],t=[],m=""){const i=[],C=[],w=/(?:\*\*|)?(?:COMMAND:|<tool_call>)\s*(OPEN_TAB|DELETE_TAB|DELETE_FOLDER|MOVE_TAB|COPY_TAB|ADD_TAB|CLOSE_TAB|RENAME_FOLDER|RESTORE_FOLDER|SCHEDULE_FOLDER|SCHEDULE_TAB|CLEAR_SCHEDULE|LOCK_FOLDER|EDIT_TAB|RENAME_TAB)\s+([^<\n*]+?)(?:>|\*\*|)?(?=\n|$)/gi;let p;for(;(p=w.exec(d))!==null;){C.push(p[0]);const n=p[1].toUpperCase(),u=v(p[2].trim());i.push({type:n,args:u,raw:p[0]})}const b=/<invoke\s+name="([^"]+)"[\s\S]*?>([\s\S]*?)<\/invoke>/gi;let s;for(;(s=b.exec(d))!==null;){const n=s[1].toLowerCase(),u=s[2],g=/<parameter\s+name="([^"]+)"\s*>(.*?)<\/parameter>/gi;let l;const r={};for(;(l=g.exec(u))!==null;)r[l[1].toLowerCase()]=l[2].trim();if(n==="browser_navigate"||n==="open_tab"||n==="browser_open")if(r.url&&R(r.url))i.push({type:"OPEN_TAB",args:{url:r.url},raw:s[0]});else if(r.search_query||r.query){const e=r.search_query||r.query;i.push({type:"OPEN_TAB",args:{url:`https://www.google.com/search?q=${encodeURIComponent(e)}`},raw:s[0]})}else(r.action==="youtube"||r.action==="music")&&i.push({type:"OPEN_TAB",args:{url:"https://www.youtube.com/results?search_query=focus+music"},raw:s[0]})}if(!i.some(n=>n.type==="ADD_TAB")){const n=d.split(`
`);let u=null;const g=[...h];t&&Array.isArray(t)&&t.forEach(r=>{r.tabs&&g.push(...r.tabs)});const l=r=>{const e=A(r).toLowerCase();return g.find(_=>{if(!_)return!1;const E=A(_.title||"").toLowerCase(),o=(_.url||"").toLowerCase();return!!(E&&(E===e||E.includes(e)||e.includes(E))||e.includes("chatgpt")&&o.includes("chatgpt")||e.includes("gemini")&&o.includes("gemini")||e.includes("openrouter")&&o.includes("openrouter")||e.includes("youtube")&&o.includes("youtube")||(e.includes("twitter")||e.includes("x ("))&&(o.includes("twitter")||o.includes("x.com"))||e.includes("linkedin")&&o.includes("linkedin")||e.includes("keep")&&o.includes("keep.google")||e.includes("apollo")&&o.includes("apollo.io")||e.includes("maps")&&(o.includes("maps")||o.includes("apify"))||e.includes("color hunt")&&o.includes("colorhunt")||e.includes("github")&&o.includes("github")||e.includes("vercel")&&o.includes("vercel"))})};for(const r of n){const e=r.trim();if(!e)continue;const _=e.match(/^(?:###\s*|\*\*\s*|\d+[\.\)]\s*)?([A-Za-z0-9\s&/\-_]+?)(?:\s+Folder|\s+Workspace)?(?:\*\*)?:\s*$/i);if(_&&!e.toLowerCase().includes("proposed folder")&&!e.toLowerCase().includes("creating and organizing")&&!e.toLowerCase().includes("organize your")){const o=_[1].trim();if(o.length>=2&&o.length<=40){u=o;continue}}const E=e.match(/^Adding\s+(.+?)\s+to\s+(?:the\s+)?(.+?)(?:\s+folder|\s+workspace)?$/i);if(E){const o=E[1].trim(),O=(E[2]?.trim()||u||"General").replace(/^["']|["']$/g,""),c=l(o);c&&c.url&&(i.some(f=>f.type==="ADD_TAB"&&f.args.url===c.url)||i.push({type:"ADD_TAB",args:{folder:O,url:c.url,title:A(c.title||o)},raw:`COMMAND: ADD_TAB folder="${O}" url="${c.url}" title="${A(c.title||o)}"`}));continue}if(u){const o=e.match(/^(?:[-*•]\s*)?(?:\[(.+?)\]\((https?:\/\/[^\s)]+)\)|([^(]+?)\s*\((https?:\/\/[^\s)]+)\))/i);if(o){const c=A((o[1]||o[3]||"").trim()),f=(o[2]||o[4]||"").trim();R(f)&&(i.some(y=>y.type==="ADD_TAB"&&y.args.url===f)||i.push({type:"ADD_TAB",args:{folder:u,url:f,title:c||f},raw:`COMMAND: ADD_TAB folder="${u}" url="${f}" title="${c||f}"`}));continue}const O=e.match(/^([A-Za-z0-9\s&/\-_]+?)\s*[-–—:]\s*(.+)$/i);if(O&&!e.startsWith("Adding")&&!e.toLowerCase().startsWith("http")){const c=O[1].trim(),f=O[2].trim();if(c.length>=2&&c.length<=40&&f.includes(",")){const y=f.split(",").map(D=>D.trim());for(const D of y){const T=l(D);T&&T.url&&(i.some(L=>L.type==="ADD_TAB"&&L.args.url===T.url)||i.push({type:"ADD_TAB",args:{folder:c,url:T.url,title:A(T.title||D)},raw:`COMMAND: ADD_TAB folder="${c}" url="${T.url}" title="${A(T.title||D)}"`}))}}}}}}let a=d;for(const n of C)a=a.replace(n,"");if(a=a.replace(/<dots_function_call>[\s\S]*?<\/dots_function_call>/gi,"").replace(/<invoke[\s\S]*?<\/invoke>/gi,"").replace(/<function_calls>[\s\S]*?<\/function_calls>/gi,"").replace(/<tool_call>[\s\S]*?<\/tool_call>/gi,"").replace(/<\/?(?:dots_function_call|invoke|parameter|tool_call|function_calls)[^>]*>/gi,"").trim(),!a){const n=m.toLowerCase(),u=h.filter(M),g=t&&t.length>0;if(n.includes("summar")||n.includes("tab")||n.includes("active")||n.includes("workspace")){let l="";u.length>0?l+=`### 📑 Active Open Browser Tabs

Here are the ${u.length} tab${u.length>1?"s":""} currently active in your browser:

`+u.map((r,e)=>`${e+1}. **${r.title||"Untitled"}**
   *${r.url}*`).join(`

`):l+=`### 📑 Active Open Browser Tabs

*You currently have no external browser tabs open.*`,g&&(l+=`

---

### 📂 Saved Workspaces Context

`,t.forEach(r=>{if(r.isLocked){l+=`#### **${r.name}** [🔒 Locked]
*(Unlock this folder in Folders view to inspect tabs)*

`;return}const e=r.tabs?.length||0;l+=`#### **${r.name}** (${e} tab${e===1?"":"s"})
`,r.tabs&&r.tabs.length>0?l+=r.tabs.map(_=>`- **${_.title||"Untitled"}** (*${_.url}*)`).join(`
`)+`

`:l+=`*(Empty folder)*

`})),l+=`
*You can ask me to open tabs, group them into a workspace, close inactive tabs, or set open/close timers.*`,a=l}else n.includes("news")||n.includes("ai")?(a=`### 🔍 AI News & Updates

I have prepared a live search for the latest news and breakthroughs in AI. Click **Approve & Execute** below to open the search results in a new tab.`,i.some(l=>l.type==="OPEN_TAB")||i.push({type:"OPEN_TAB",args:{url:"https://www.google.com/search?q=latest+news+on+AI"},raw:'COMMAND: OPEN_TAB url="https://www.google.com/search?q=latest+news+on+AI"'})):n.includes("music")||n.includes("youtube")||n.includes("focus")?(a=`### 🎵 Focus Music on YouTube

I have prepared a curated focus and study music stream for you on YouTube. Click **Approve & Execute** below to launch it.`,i.some(l=>l.type==="OPEN_TAB")||i.push({type:"OPEN_TAB",args:{url:"https://www.youtube.com/results?search_query=focus+music+work+study"},raw:'COMMAND: OPEN_TAB url="https://www.youtube.com/results?search_query=focus+music+work+study"'})):a="I have processed your request. Please review the suggested workspace actions below."}return{cleanedText:a,pendingCommands:i}}function I(d){return d.replace(/<dots_function_call>[\s\S]*?<\/dots_function_call>/gi,"").replace(/<invoke[\s\S]*?<\/invoke>/gi,"").replace(/<\/?(?:dots_function_call|invoke|parameter|tool_call|function_calls)[^>]*>/gi,"").replace(/(?:\*\*|)?COMMAND:[^\n]*\n?/gi,"")}export{I as n,F as t};
